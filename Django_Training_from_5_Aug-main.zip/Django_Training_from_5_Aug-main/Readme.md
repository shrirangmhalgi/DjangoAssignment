Day 1

Frameworks vs library
Django
MVT
venv/conda
conda commands  -> venv -> try
startproject
settings.py and manage.py
startapp

Day 1 Session 2

Requirements.txt
Model
views
Templates
Jinja 

Day 2 Session 1

Models ,
migrations,
superuser,
admin,
register,
ORM,
Django Shell,

Day 2 Session 2 

API 
Types of API
JSON
Serializer
Req,Res Path

Day 3 Session 1
post
single user data 
put single user data
patch 
delete
postman

Day 3 Session 2
forms
traditional form 
django form
multipart/form-data in template
csrf token and its flow

Day 4 Session 1 
Sessions
Web storage
implementation 

Day 4 Session 2
AuthZ and AuthN
