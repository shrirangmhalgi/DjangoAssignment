from django.apps import AppConfig


class LoginSystemAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'login_system_app'
